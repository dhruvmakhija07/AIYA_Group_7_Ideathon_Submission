```
Image: { Bytes: this.uimage_bytes },
```

```
MaxLabels: this.numLabels, 
```

```
MinConfidence: this.confidence, 
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_

```
    <AnalyzePhoto/>
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_

```
<td>({{ parseFloat(objectDetected.Confidence).toFixed(1) }}%)</td>
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_


```
import { RekognitionClient, DetectLabelsCommand } from "@aws-sdk/client-rekognition";
```


```
rekognitionSuccess: false,
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_

 
```
                if (imageFile.size > 5242880) {  
                    alert("Your file is too large, please select a file that is 5MB or less.");
                    return;
                }
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_


```
fileReader.readAsDataURL(imageFile);
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_


```
accessKeyId: import.meta.env.VITE_AWS_ACCESS_KEY_ID,
```


```
secretAccessKey: import.meta.env.VITE_AWS_SECRET_ACCESS_KEY,
```


```
sessionToken: import.meta.env.VITE_AWS_SESSION_TOKEN,
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_


```
this.objectsDetected = response; 
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_


```
<img id="userPhoto" :src="userPhoto" class="photoFrame" width="720" />
```

-_-_-_-_-_-_-_-_-_-_-_-_-_-_

```
<button class="button" v-if="warningAccepted" @click="openFilePicker">Choose a photo</button>
```

```
<input type="file" ref="fileInput" id="input" v-if="warningAccepted" @change="onFileSelected" accept="image/*" style="display: none" />
```